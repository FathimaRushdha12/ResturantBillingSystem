/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Restaurant;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Mohamed Rismi
 */
public class ParentClass {
    
    public double Meals;
    public double Drinks;
    public double Total;
    public double TotalCost;    //total with tax.
    
            
    public double ChickenBurger;
    public double Sandwich;
    public double Frenchfries;
    public double Pizza;
    public double Hotdog;
    
    public double ChocolateMilkShake;
    public double VenilaMilkShake;
    public double HotChocolate;
    public double Coffee;
    public double Mojito;
    
    
    public double GetAmount()
    {
        Meals = ChickenBurger + Sandwich + Frenchfries + Pizza + Hotdog;
        Drinks =ChocolateMilkShake + VenilaMilkShake + HotChocolate + Coffee + Mojito;
        Total = Meals + Drinks ;
        TotalCost = Total;
        return TotalCost;

    }
    
    private JFrame frame;
    
    public void iExitSystem(){
        frame = new JFrame("Exit");
        
        if (JOptionPane.showConfirmDialog(frame, "confirm if you want to exit","Restaurant Billing System",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
                System.exit(0);
        }
    }
    
    //==============================================Price========================================
    
    public double pChickenBurger = 450;                       //pChickenBurger is ChickenBurger price
    public double pSandwich = 390;
    public double pFrenchfries = 330;
    public double pPizza = 1500;
    public double pHotdog = 300;
    
    public double pChocolateMilkShake = 245;
    public double pVenilaMilkShake = 210;
    public double pHotChocolate = 240;
    public double pCoffee = 180;
    public double pMojito = 170;
    
    //==========================================================================================
    
    public double Tax = 2.5;
    
    public Double cFindTex(double cAmount)
    {
        double FindTax = cAmount *( Tax/100);
        return FindTax;
    }
    public double DisAmount = 2.0;
    
    public double Discount(double cDis)
    {
        double dis = cDis*(DisAmount/100);
        return dis;
    }
    //==========================================================================================
}
